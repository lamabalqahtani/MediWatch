import pandas as pd
import numpy as np
import streamlit as st
import plotly.express as px
from pathlib import Path
from streamlit_autorefresh import st_autorefresh
from streamlit_option_menu import option_menu


# PAGE CONFIGURATION & STATE INITIALIZATION
st.set_page_config(
    page_title="Vitalink | ICU Command Center",
    page_icon="🩺",
    layout="wide",
    initial_sidebar_state="expanded"
)

if "acknowledged_patients" not in st.session_state:
    st.session_state.acknowledged_patients = set()

if "active_nav" not in st.session_state:
    st.session_state.active_nav = "Patients"

if "lang" not in st.session_state:
    st.session_state.lang = "العربية"


# FUTURISTIC COMMAND CENTER CSS
st.markdown("""
    <style>
    .main { background-color: #040814; }
    .stApp { background-color: #040814; color: #F8FAFC; }
    
    [data-testid="stSidebar"] {
        background-color: #070D1D;
        color: #F8FAFC;
        border-right: 1px solid #1E293B;
    }
    [data-testid="stSidebar"] h2, [data-testid="stSidebar"] p, [data-testid="stSidebar"] span, [data-testid="stSidebar"] label {
        color: #F8FAFC !important;
    }
    [data-testid="stSidebar"] .stSelectbox div[data-baseweb="select"] > div {
        background-color: #0F172A !important;
        color: #FFFFFF !important;
        border-color: #3B82F6 !important;
        border-radius: 8px;
    }
    [data-testid="stSidebar"] .stSelectbox svg {
        fill: #FFFFFF !important;
    }

    h1, h2, h3, h4, h5, h6, p, span, label, div, .stMarkdown {
        color: #F8FAFC;
    }
    
    .summary-banner {
        background: linear-gradient(135deg, #0D1B2A 0%, #1B263B 100%);
        border: 1px solid #284B63;
        border-radius: 12px;
        padding: 14px 18px;
        margin-bottom: 18px;
        box-shadow: 0 6px 20px rgba(0, 0, 0, 0.4);
        display: flex;
        justify-content: space-around;
        align-items: center;
        flex-wrap: wrap;
    }
    .stat-box {
        text-align: center;
        flex: 1;
        min-width: 110px;
        padding: 4px;
        border-right: 1px solid rgba(255, 255, 255, 0.1);
    }
    .stat-box:last-child {
        border-right: none;
    }
    .stat-number {
        font-size: 22px;
        font-weight: 800;
        color: #38BDF8;
        margin-top: 2px;
        line-height: 1.2;
    }
    .stat-label {
        font-size: 12px;
        color: #94A3B8;
        font-weight: 600;
        white-space: nowrap;
    }

    .icu-pod {
        background: linear-gradient(135deg, #0D1B2A 0%, #1B263B 100%);
        border: 1px solid #284B63;
        border-radius: 12px;
        padding: 14px;
        margin-bottom: 14px;
        box-shadow: 0 4px 16px rgba(0, 0, 0, 0.4);
    }
    .pod-normal { border-left: 5px solid #10B981; }
    .pod-warning { border-left: 5px solid #F59E0B; }
    .pod-danger { border-left: 5px solid #EF4444; background: linear-gradient(135deg, #1A0F14 0%, #2D1519 100%); }
    .pod-acked { border-left: 5px solid #3B82F6; opacity: 0.85; }

    .vital-box {
        background: rgba(255, 255, 255, 0.04);
        border: 1px solid rgba(255, 255, 255, 0.08);
        border-radius: 8px;
        padding: 6px 10px;
        text-align: center;
        flex: 1;
        margin: 0 3px;
    }
    .vital-label {
        font-size: 11px;
        color: #94A3B8;
        font-weight: 600;
        margin-bottom: 2px;
    }
    .vital-value {
        font-size: 13px;
        font-weight: 700;
        color: #F8FAFC;
    }

    /* ألوان خلفيات المربعات للمؤشرات ذات المربعات */
    .box-normal { background: rgba(255, 255, 255, 0.04); border: 1px solid rgba(255, 255, 255, 0.08); }
    .box-warning { background: rgba(245, 158, 11, 0.25) !important; border: 1px solid #F59E0B !important; }
    .box-danger { background: rgba(239, 68, 68, 0.3) !important; border: 1px solid #EF4444 !important; }

    /* ألوان النصوص للقيم التي ليس لها مربعات (مثل BP و MAP) */
    .val-normal { color: #10B981; }
    .val-warning { color: #F59E0B; font-weight: 700; }
    .val-danger { color: #EF4444; font-weight: 800; }

    input, textarea {
        background-color: #0B132B !important;
        color: #FFFFFF !important;
        border-color: #1D3557 !important;
        border-radius: 8px !important;
    }
    
    .stTabs [data-baseweb="tab-list"] { gap: 10px; }
    .stTabs [data-baseweb="tab"] {
        background-color: #0B132B;
        border-radius: 8px;
        color: #FFFFFF;
        padding: 8px 20px;
        font-size: 14px;
        border: 1px solid #1D3557;
    }
    .stTabs [aria-selected="true"] {
        background-color: #2563EB !important;
        border-color: #3B82F6 !important;
    }
    </style>
""", unsafe_allow_html=True)

# SIDEBAR & LANGUAGE SELECTION
with st.sidebar:
    selected_lang_option = st.selectbox(
        "🌐 Language / اللغة", 
        ["العربية", "English"], 
        index=0 if st.session_state.lang == "العربية" else 1
    )
    
    if selected_lang_option != st.session_state.lang:
        st.session_state.lang = selected_lang_option
        st.rerun()

lang = st.session_state.lang

if lang == "العربية":
    txt = {
        "sidebar_subtitle": "نظام القيادة والتحكم للمراقبة السريرية",
        "title": "🏥 مركز المراقبة السريرية الذكي",
        "caption": "متابعة مركزة لأسرّة المرضى مع التحديث اللحظي للعلامات الحيوية ونظام الإنذار المبكر.",
        "total_p": "إجمالي الأسرة",
        "norm_p": "🟢 مستقر",
        "acked_p": "🔵 تم التدخل",
        "low_p": "🟡 تحت الملاحظة",
        "high_p": "🔴 حالات حرجة",
        "search": "🔍 بحث سريع برقم السرير أو معرّف المريض (مثال: Bed-01 أو P0001):",
        "tab_all": "جميع الأسرة",
        "tab_danger": "🔴 الحالات الحرجة",
        "tab_warning": "🟡 تحت الملاحظة",
        "tab_acked": "🔵 تم التعامل",
        "alerts_title": "🚨 مركز الإنذار المبكر والتدخل السريع",
        "alerts_caption": "متابعة فورية للتنبيهات الحرجة.",
        "no_alerts": "✨ ممتاز! جميع المؤشرات ضمن النطاق الآمن.",
        "trends_title": "📈 لوحة التحليل العميق والمؤشرات",
        "trends_caption": "استعراض تفصيلي لتطور العلامات الحيوية للمريض.",
        "history_title": "🕒 السجلات والتقارير التاريخية",
        "history_caption": "الأرشيف الكامل للقراءات التاريخية.",
        "ack_btn": "✅ اعتماد التدخل الطبي",
        "reset_ack": "🔄 إعادة تعيين الأرشيف (إظهار التنبيهات مجدداً)",
        "search_hist": "🔍 بحث في السجل:",
        "select_patient": "اختر المريض للتحليل:",
        "critical_badge": "🔴 خطر حرِج",
        "observation_badge": "🟡 ملاحظة",
        "stable_badge": "🟢 مستقر",
        "acked_badge": "🔵 تم التدخل",
        "reason_label": "السبب:",
        "age_label": "العمر",
        "bed_label": "السرير",
        "status_label": "الحالة",
        "no_data": "لا توجد بيانات كافية.",
        "no_cases": "لا توجد حالات ضمن هذه الفئة حالياً."
    }
else:
    txt = {
        "sidebar_subtitle": "Clinical Monitoring Command Center",
        "title": "🏥 Smart Clinical Monitoring Center",
        "caption": "Focused patient bed monitoring with real-time vital signs and early warning system.",
        "total_p": "Total Beds",
        "norm_p": "🟢 Stable",
        "acked_p": "🔵 Intervened",
        "low_p": "🟡 Observation",
        "high_p": "🔴 Critical",
        "search": "🔍 Quick search by Bed or Patient ID:",
        "tab_all": "All Beds",
        "tab_danger": "🔴 Critical",
        "tab_warning": "🟡 Observation",
        "tab_acked": "🔵 Acknowledged",
        "alerts_title": "🚨 Early Warning & Rapid Response",
        "alerts_caption": "Immediate tracking of critical alerts.",
        "no_alerts": "✨ Excellent! All vitals are within safe ranges.",
        "trends_title": "📈 Advanced Analytics Dashboard",
        "trends_caption": "Detailed review of patient vital sign progression.",
        "history_title": "🕒 Clinical Archive & Reports",
        "history_caption": "Complete archive of historical readings.",
        "ack_btn": "✅ Acknowledge Intervention",
        "reset_ack": "🔄 Reset Archive",
        "search_hist": "🔍 Search history:",
        "select_patient": "Select patient for analysis:",
        "critical_badge": "🔴 Critical",
        "observation_badge": "🟡 Observation",
        "stable_badge": "🟢 Stable",
        "acked_badge": "🔵 Ack",
        "reason_label": "Reason:",
        "age_label": "Age",
        "bed_label": "Bed",
        "status_label": "Status",
        "no_data": "Insufficient data available.",
        "no_cases": "No cases found in this category."
    }

with st.sidebar:
    st.markdown(f"""
        <div style='padding: 10px 0;'>
            <h2 style='margin:0; font-size: 22px; font-weight: 700; color: #38BDF8;'>🩺 Vitalink</h2>
            <p style='margin:0; font-size: 12px; opacity: 0.8; color: #94A3B8;'>{txt['sidebar_subtitle']}</p>
        </div>
    """, unsafe_allow_html=True)
    st.divider()


#   DATA LOADING
@st.cache_data
def load_Vitalink_data():
    BASE_DIR = Path(__file__).resolve().parent
    CSV_PATH = BASE_DIR / "demo_readings.csv"
    df = pd.read_csv(CSV_PATH)
    selected_patients = (
        df["patient_id"]
        .drop_duplicates()
        .sample(n=min(45, df["patient_id"].nunique()), random_state=42)
    )
    df = df[df["patient_id"].isin(selected_patients)].copy()
    df = df.sort_values(["patient_id", "hour_from_admission"]).copy()
    return df

df_all = load_Vitalink_data()

unique_pids = df_all["patient_id"].unique()
bed_mapping = {p_id: f"Bed-{(i+1):02d}" for i, p_id in enumerate(unique_pids)}
df_all["bed_no"] = df_all["patient_id"].map(bed_mapping)
df_all["display_id"] = df_all["patient_id"].apply(lambda x: f"P{int(x):04d}" if str(x).isdigit() else f"P-{x}")
df_all["bp_combined"] = df_all["systolic_bp"].astype(str) + " / " + df_all["diastolic_bp"].astype(str)


#   CLINICAL RULE ENGINE & VITAL STYLING

def evaluate_vitals(row):
    risk_levels = []
    reasons = []

    t = row["temperature_c"]
    if 38.5 <= t <= 39.5 or t < 35.0:
        risk_levels.append("Red")
        reasons.append(f"حرارة حرجة ({t}°C)" if lang == "العربية" else f"Critical Temperature ({t}°C)")
    elif (37.5 <= t < 38.5) or (35.0 <= t < 36.0):
        risk_levels.append("Orange")
        reasons.append(f"ارتفاع/انخفاض طفيف بالحرارة ({t}°C)" if lang == "العربية" else f"Mild Temp Variance ({t}°C)")

    hr = row["heart_rate"]
    if hr > 120 or hr < 50:
        risk_levels.append("Red")
        reasons.append(f"نبض قلب حرِج ({hr} bpm)" if lang == "العربية" else f"Critical Heart Rate ({hr} bpm)")
    elif (110 <= hr <= 120) or (50 <= hr < 60):
        risk_levels.append("Orange")
        reasons.append(f"نبض قلب غير مستقر ({hr} bpm)" if lang == "العربية" else f"Unstable Heart Rate ({hr} bpm)")

    rr = row["respiratory_rate"]
    if rr > 25 or rr < 10:
        risk_levels.append("Red")
        reasons.append(f"معدل تنفس حرِج ({rr})" if lang == "العربية" else f"Critical Resp Rate ({rr})")
    elif 21 <= rr <= 25:
        risk_levels.append("Orange")
        reasons.append(f"معدل تنفس مرتفع ({rr})" if lang == "العربية" else f"High Resp Rate ({rr})")

    sbp = row["systolic_bp"]
    if sbp < 90:
        risk_levels.append("Red")
        reasons.append(f"ضغط دم انقباضي حرِج ({sbp})" if lang == "العربية" else f"Critical Systolic BP ({sbp})")
    elif sbp < 100:
        risk_levels.append("Orange")
        reasons.append(f"ضغط دم انقباضي منخفض ({sbp})" if lang == "العربية" else f"Low Systolic BP ({sbp})")

    spo2 = row["spo2_pct"]
    if spo2 < 90:
        risk_levels.append("Red")
        reasons.append(f"تشبع الأكسجين حرِج ({spo2}%)" if lang == "العربية" else f"Critical SpO₂ ({spo2}%)")
    elif 90 <= spo2 <= 94:
        risk_levels.append("Orange")
        reasons.append(f"تشبع أكسجين منخفض ({spo2}%)" if lang == "العربية" else f"Low SpO₂ ({spo2}%)")

    map_val = (row["systolic_bp"] + (2 * row["diastolic_bp"])) / 3
    if map_val < 65 or map_val > 120:
        risk_levels.append("Red")
        reasons.append(f"متوسط ضغط دم حرِج MAP ({round(map_val, 1)})" if lang == "العربية" else f"Critical MAP ({round(map_val, 1)})")
    elif (65 <= map_val < 70) or (100 < map_val <= 120):
        risk_levels.append("Orange")
        reasons.append(f"متوسط ضغط دم غير مستقر MAP ({round(map_val, 1)})" if lang == "العربية" else f"Unstable MAP ({round(map_val, 1)})")

    if "Red" in risk_levels:
        return pd.Series(["High Risk", ", ".join(reasons)])
    elif "Orange" in risk_levels:
        return pd.Series(["Low Risk", ", ".join(reasons)])
    else:
        return pd.Series(["Normal", "قراءات مستقرة وآمنة" if lang == "العربية" else "Stable & Safe Readings"])

def get_box_class(val, v_type):
    if v_type == "hr":
        if val > 120 or val < 50: return "box-danger"
        if (110 <= val <= 120) or (50 <= val < 60): return "box-warning"
    elif v_type == "spo2":
        if val < 90: return "box-danger"
        if 90 <= val <= 94: return "box-warning"
    elif v_type == "temp":
        if (38.5 <= val <= 39.5) or (val < 35.0): return "box-danger"
        if (37.5 <= val < 38.5) or (35.0 <= val < 36.0): return "box-warning"
    elif v_type == "resp":
        if val > 25 or val < 10: return "box-danger"
        if 21 <= val <= 25: return "box-warning"
    return "box-normal"

def get_text_class(val, v_type):
    if v_type == "sbp":
        if val < 90: return "val-danger"
        if val < 100: return "val-warning"
    elif v_type == "map":
        if val < 60 or val > 110: return "val-danger"
        if (60 <= val < 65) or (105 < val <= 110): return "val-warning"
    return "val-normal"

# REAL-TIME CLOCK & NAVIGATION (BULLETPROOF)
available_hours = sorted(df_all["hour_from_admission"].unique())
if "sim_hour_idx" not in st.session_state:
    st.session_state.sim_hour_idx = 0

count = st_autorefresh(interval=60 * 1000, key="global_realtime_clock")
if count > 0 and "last_count" in st.session_state and count != st.session_state.last_count:
    st.session_state.sim_hour_idx = (st.session_state.sim_hour_idx + 1) % len(available_hours)
st.session_state.last_count = count

current_hour = available_hours[st.session_state.sim_hour_idx]

current_slice = df_all[df_all["hour_from_admission"] <= current_hour]
df_current = current_slice.sort_values("hour_from_admission").groupby("patient_id").tail(1).copy()
df_current[["Risk_Level", "Alert_Reason"]] = df_current.apply(evaluate_vitals, axis=1)
df_current["Original_Risk"] = df_current["Risk_Level"]

active_alerts_count = len(df_current[
    (df_current["Original_Risk"].isin(["High Risk", "Low Risk"])) & 
    (~df_current["patient_id"].isin(st.session_state.acknowledged_patients))
])

with st.sidebar:
    page_keys = ["Patients", "Alerts", "Trends", "History"]
    
    if lang == "العربية":
        display_names = [
            "المرضى", 
            f"التنبيهات ({active_alerts_count})" if active_alerts_count > 0 else "التنبيهات", 
            "المؤشرات", 
            "السجل"
        ]
    else:
        display_names = [
            "Patients", 
            f"Alerts ({active_alerts_count})" if active_alerts_count > 0 else "Alerts", 
            "Trends", 
            "History"
        ]

    display_to_key = {display_names[i]: page_keys[i] for i in range(len(page_keys))}

    curr_key = st.session_state.active_nav
    default_idx = page_keys.index(curr_key) if curr_key in page_keys else 0

    selected_display = option_menu(
        menu_title=None,
        options=display_names,
        icons=["people", "exclamation-triangle", "graph-up", "clock-history"],
        menu_icon="cast",
        default_index=default_idx,
        key="main_navigation_menu",
        styles={
            "container": {"padding": "0!important", "background-color": "transparent"},
            "icon": {"color": "#38BDF8", "font-size": "15px"},
            "nav-link": {
                "font-size": "14px",
                "text-align": "left",
                "margin": "4px 0px",
                "color": "#F8FAFC",
                "--hover-color": "#1E293B",
            },
            "nav-link-selected": {"background-color": "#2563EB", "color": "white", "font-weight": "bold"},
        }
    )

    new_key = display_to_key.get(selected_display, st.session_state.active_nav)

    if new_key != st.session_state.active_nav:
        st.session_state.active_nav = new_key
        st.rerun()

    current_page = st.session_state.active_nav

# PAGE 1: Patients
if current_page == "Patients":
    st.markdown(f"""
        <div style='margin-bottom: 16px;'>
            <h1 style='margin:0; font-size: 24px; font-weight: 800; color: #F8FAFC;'>{txt['title']}</h1>
            <p style='margin:4px 0 0 0; color: #94A3B8; font-size: 13px;'>{txt['caption']}</p>
        </div>
    """, unsafe_allow_html=True)

    total_p = len(df_current)
    acked_p = len(df_current[df_current["patient_id"].isin(st.session_state.acknowledged_patients) & (df_current["Original_Risk"].isin(["High Risk", "Low Risk"]))])
    high_p = len(df_current[(df_current["Original_Risk"] == "High Risk") & (~df_current["patient_id"].isin(st.session_state.acknowledged_patients))])
    low_p = len(df_current[(df_current["Original_Risk"] == "Low Risk") & (~df_current["patient_id"].isin(st.session_state.acknowledged_patients))])
    norm_p = total_p - (high_p + low_p + acked_p)

    st.markdown(f"""
        <div class="summary-banner">
            <div class="stat-box">
                <div class="stat-label">{txt["total_p"]}</div>
                <div class="stat-number">{total_p}</div>
            </div>
            <div class="stat-box">
                <div class="stat-label">{txt["norm_p"]}</div>
                <div class="stat-number" style="color: #10B981;">{norm_p}</div>
            </div>
            <div class="stat-box">
                <div class="stat-label">{txt["acked_p"]}</div>
                <div class="stat-number" style="color: #3B82F6;">{acked_p}</div>
            </div>
            <div class="stat-box">
                <div class="stat-label">{txt["low_p"]}</div>
                <div class="stat-number" style="color: #F59E0B;">{low_p}</div>
            </div>
            <div class="stat-box">
                <div class="stat-label">{txt["high_p"]}</div>
                <div class="stat-number" style="color: #EF4444;">{high_p}</div>
            </div>
        </div>
    """, unsafe_allow_html=True)

    search_q = st.text_input(txt["search"], "")

    view_df = df_current.sort_values("bed_no").copy()
    if search_q:
        view_df = view_df[
            view_df["display_id"].str.contains(search_q, case=False) | 
            view_df["bed_no"].str.contains(search_q, case=False)
        ]

    tab_all, tab_danger, tab_warning, tab_acked = st.tabs([
        txt["tab_all"], txt["tab_danger"], txt["tab_warning"], txt["tab_acked"]
    ])

    def render_icu_pods(subset_df):
        if subset_df.empty:
            st.info(txt["no_cases"])
            return
        cols = st.columns(3)
        for idx, row in subset_df.reset_index(drop=True).iterrows():
            is_acked = row["patient_id"] in st.session_state.acknowledged_patients

            if is_acked:
                pod_class = "pod-acked"
                badge = txt["acked_badge"]
            elif row["Original_Risk"] == "High Risk":
                pod_class = "pod-danger"
                badge = txt["critical_badge"]
            elif row["Original_Risk"] == "Low Risk":
                pod_class = "pod-warning"
                badge = txt["observation_badge"]
            else:
                pod_class = "pod-normal"
                badge = txt["stable_badge"]
            
            hr_box_cls = get_box_class(row['heart_rate'], "hr")
            spo2_box_cls = get_box_class(row['spo2_pct'], "spo2")
            resp_box_cls = get_box_class(row['respiratory_rate'], "resp")
            temp_box_cls = get_box_class(row['temperature_c'], "temp")
            
            sbp_val = row['systolic_bp']
            sbp_text_cls = get_text_class(sbp_val, "sbp")
            
            map_val = round((row['systolic_bp'] + (2 * row['diastolic_bp'])) / 3, 1)
            map_text_cls = get_text_class(map_val, "map")

            with cols[idx % 3]:
                st.markdown(f"""
                <div class="icu-pod {pod_class}">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">
                        <span style="font-size: 15px; font-weight: 700; color: #38BDF8;">🛏️ {row['bed_no']}</span>
                        <span style="font-size: 11px; font-weight: bold; background: rgba(255,255,255,0.08); padding: 3px 8px; border-radius: 6px;">{row['display_id']} | {badge}</span>
                    </div>
                    <div style="display: flex; justify-content: space-between; margin-bottom: 6px;">
                        <div class="vital-box {hr_box_cls}">
                            <div class="vital-label">❤️ HR</div>
                            <div class="vital-value">{row['heart_rate']} <span style="font-size:9px; color:#F8FAFC;">bpm</span></div>
                        </div>
                        <div class="vital-box {spo2_box_cls}">
                            <div class="vital-label">🩸 SpO₂</div>
                            <div class="vital-value">{row['spo2_pct']}%</div>
                        </div>
                    </div>
                    <div style="display: flex; justify-content: space-between;">
                        <div class="vital-box {resp_box_cls}">
                            <div class="vital-label">🫁 Resp</div>
                            <div class="vital-value">{row['respiratory_rate']}</div>
                        </div>
                        <div class="vital-box {temp_box_cls}">
                            <div class="vital-label">🌡️ Temp</div>
                            <div class="vital-value">{row['temperature_c']}°C</div>
                        </div>
                    </div>
                    <div style="font-size: 12px; margin-top: 8px; border-top: 1px solid rgba(255,255,255,0.1); padding-top: 6px; display: flex; justify-content: space-between; align-items: center;">
                        <span style="color: #94A3B8; font-size: 11px;">BP (mmHg):</span>
                        <span class="{sbp_text_cls}">{row['systolic_bp']} / {row['diastolic_bp']}</span>
                    </div>
                    <div style="font-size: 12px; margin-top: 4px; display: flex; justify-content: space-between; align-items: center;">
                        <span style="color: #94A3B8; font-size: 11px;">MAP (mmHg):</span>
                        <span class="{map_text_cls}">{map_val}</span>
                    </div>
                </div>
                """, unsafe_allow_html=True)

    with tab_all:
        render_icu_pods(view_df)
    with tab_danger:
        render_icu_pods(view_df[(view_df["Original_Risk"] == "High Risk") & (~view_df["patient_id"].isin(st.session_state.acknowledged_patients))])
    with tab_warning:
        render_icu_pods(view_df[(view_df["Original_Risk"] == "Low Risk") & (~view_df["patient_id"].isin(st.session_state.acknowledged_patients))])
    with tab_acked:
        render_icu_pods(view_df[view_df["patient_id"].isin(st.session_state.acknowledged_patients) & (view_df["Original_Risk"].isin(["High Risk", "Low Risk"]))])


# PAGE 2: Alerts
elif current_page == "Alerts":
    st.title(txt["alerts_title"])
    st.caption(txt["alerts_caption"])

    active_alerts = df_current[
        (df_current["Original_Risk"].isin(["High Risk", "Low Risk"])) & 
        (~df_current["patient_id"].isin(st.session_state.acknowledged_patients))
    ].copy()

    # ترتيب التنبيهات بحيث تكون الحالات الحرجة (High Risk / الحمراء) في البداية
    if not active_alerts.empty:
        active_alerts["sort_priority"] = active_alerts["Original_Risk"].apply(lambda x: 0 if x == "High Risk" else 1)
        active_alerts = active_alerts.sort_values("sort_priority")

    if active_alerts.empty:
        st.success(txt["no_alerts"])
    else:
        for _, row in active_alerts.iterrows():
            card_style = "pod-danger" if row["Original_Risk"] == "High Risk" else "pod-warning"
            level_text = txt["critical_badge"] if row["Original_Risk"] == "High Risk" else txt["observation_badge"]
            map_val_alert = round((row['systolic_bp'] + (2 * row['diastolic_bp'])) / 3, 1)
            
            with st.container():
                st.markdown(f"""
                <div class="icu-pod {card_style}">
                    <h3 style="margin:0 0 6px 0; color: #F8FAFC; font-size: 16px;">{level_text} — {txt['bed_label']} {row['bed_no']} ({row['display_id']})</h3>
                    <p style="margin:4px 0; font-size: 13px;"><b>{txt['reason_label']}</b> {row['Alert_Reason']}</p>
                    <small style="color: #94A3B8; font-size: 11px;">HR: {row['heart_rate']} | SpO2: {row['spo2_pct']}% | Temp: {row['temperature_c']}°C | BP: {row['systolic_bp']}/{row['diastolic_bp']} | MAP: {map_val_alert}</small>
                </div>
                """, unsafe_allow_html=True)
                
                if st.button(f"{txt['ack_btn']} ({row['bed_no']})", key=f"ack_{row['patient_id']}"):
                    st.session_state.acknowledged_patients.add(row["patient_id"])
                    st.rerun()
                st.write("---")

    if st.session_state.acknowledged_patients:
        if st.button(txt["reset_ack"]):
            st.session_state.acknowledged_patients.clear()
            st.rerun()


# PAGE 3: Trends

elif current_page == "Trends":
    st.title(txt["trends_title"])
    st.caption(txt["trends_caption"])

    selected_pid = st.selectbox(
        txt["select_patient"],
        df_all["patient_id"].unique(),
        format_func=lambda x: f"Patient P{int(x):04d}" if str(x).isdigit() else f"Patient {x}"
    )

    p_data = df_all[(df_all["patient_id"] == selected_pid) & (df_all["hour_from_admission"] <= current_hour)].copy()

    if p_data.empty:
        st.warning(txt["no_data"])
    else:
        p_data[["Risk_Level", "Alert_Reason"]] = p_data.apply(evaluate_vitals, axis=1)
        latest = p_data.iloc[-1]
        
        col_a, col_b, col_c = st.columns(3)
        col_a.metric(txt["age_label"], f"{latest['age']}")
        col_b.metric(txt["bed_label"], f"{latest['bed_no']}")
        col_c.metric(txt["status_label"], latest['Risk_Level'])

        st.markdown("---")

        hr_title = "Heart Rate Trend (HR)" if lang == "English" else "مؤشر نبض القلب (HR)"
        temp_title = "Temperature Trend (°C)" if lang == "English" else "مؤشر درجات الحرارة (°C)"
        spo2_title = "Oxygen Saturation (SpO₂)" if lang == "English" else "مؤشر تشبع الأكسجين (SpO₂)"
        bp_title = "Blood Pressure Trend (BP)" if lang == "English" else "مؤشر ضغط الدم (BP)"

        c1, c2 = st.columns(2)
        with c1:
            fig_hr = px.line(p_data, x="hour_from_admission", y="heart_rate", markers=True, title=hr_title, template="plotly_dark")
            st.plotly_chart(fig_hr, use_container_width=True)
            
            fig_temp = px.line(p_data, x="hour_from_admission", y="temperature_c", markers=True, title=temp_title, template="plotly_dark")
            st.plotly_chart(fig_temp, use_container_width=True)

        with c2:
            fig_spo2 = px.line(p_data, x="hour_from_admission", y="spo2_pct", markers=True, title=spo2_title, template="plotly_dark")
            st.plotly_chart(fig_spo2, use_container_width=True)
            
            fig_bp = px.line(p_data, x="hour_from_admission", y=["systolic_bp", "diastolic_bp"], markers=True, title=bp_title, template="plotly_dark")
            st.plotly_chart(fig_bp, use_container_width=True)


# PAGE 4: History
elif current_page == "History":
    st.title(txt["history_title"])
    st.caption(txt["history_caption"])

    search_h = st.text_input(txt["search_hist"], "")
    hist_df = df_all[df_all["hour_from_admission"] <= current_hour].copy()
    
    if search_h:
        hist_df = hist_df[
            hist_df["display_id"].str.contains(search_h, case=False) | 
            hist_df["bed_no"].str.contains(search_q if 'search_q' in locals() else search_h, case=False)
        ]

    display_history = hist_df[[
        "display_id", "bed_no", "hour_from_admission", 
        "heart_rate", "spo2_pct", "respiratory_rate", 
        "temperature_c", "bp_combined"
    ]].copy()

    if lang == "العربية":
        display_history.columns = [
            "معرّف المريض", "رقم السرير", "ساعة التنويم", 
            "نبض القلب (HR)", "الأكسجين (SpO₂ %)", "معدل التنفس", 
            "درجة الحرارة (°C)", "ضغط الدم (BP)"
        ]
    else:
        display_history.columns = [
            "Patient ID", "Bed No", "Admission Hour", 
            "Heart Rate (HR)", "SpO₂ (%)", "Respiratory Rate", 
            "Temperature (°C)", "Blood Pressure (BP)"
        ]

    st.dataframe(
        display_history.head(200), 
        use_container_width=True, 
        hide_index=True
    )

st.divider()
st.caption("Vitalink | Real-Time Clinical Rule-Based Monitoring | Command Center v3.15")